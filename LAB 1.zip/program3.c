/*
JAYASH PREM
OOPs LAB 
DATE:20/07/2022
QUESTION 3;
*/

struct emp{
	char id[10];
	char name[15];
	int age;
	int BS;
	float GS;
};

#include<stdio.h>
int main()
{	
	int n,i;
	float HRA,DA,bs;
	printf("Enter total number of emp(n): ");
	scanf("%d",&n);
	
	struct emp data[n];
	struct emp *ptr;
	ptr=data;
	
	for(i=0;i<n;i++)
	{
		printf("\n-----------for EMP %d-------------\n",i+1);
		
		printf("ENTER ID: ");
		scanf(" %s",ptr->id);
		
		printf("ENTER NAME: ");
		scanf(" %[^\n]s",ptr->name);
		
		printf("ENTER AGE: ");
		scanf("%d",&ptr->age);
		
		printf("ENTER BASIC SALARY (BS): ");
		scanf(" %d",&ptr->BS);
		
		ptr++;
	}
	ptr=data;
	
	for(i=0;i<n;i++)
	{
		bs=ptr->BS;
		DA=(80.0/100.0)*bs;
		HRA=(10.0/100.0)*bs;
		ptr->GS=bs+DA+HRA;
		ptr++;
	}
	
	ptr=data;
	
	printf("%-10s\t%-15s\t%-3s\t%-8s\t%-8s\n\n","EMP ID","NAME","AGE","BS","GS");
	for(i=0;i<n;i++)
	{
		printf("%-10s\t%-15s\t%-3d\t%-8d\t%-8.02f\n",ptr->id,ptr->name,ptr->age,ptr->BS,ptr->GS);
		ptr++;	
	}
	
	return 0;
}
