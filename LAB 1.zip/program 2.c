/*
Jayash prem
OOPs LAB ONE
QUESTION 2: WAP to input,roll number and marks in 5 subject for n number of students.write function to:-
a. find total marks and percentage of all n student 
b. Display details of a student with a given roll number
c. Display the details for all the student having percentage in a given range.
d. Sort the array in ascending order of the marks.
date: 20/07/2022 
*/
#include<stdio.h>
struct student{
	char name[20];
	long int roll;
	int marks[5];
	int TM;
	float per;
};
void accept(struct student list[100],int s)
{
	int i,j;
	for(i=0;i<s;i++)
	{
		printf("--------------STUDENT %d---------------------\n",i+1);
		printf("ENTER NAME: ");
		scanf(" %[^\n]s",&list[i].name);
		
		printf("Enter ROLL no. : ");
		scanf("%d",&list[i].roll);
		
		printf("ENTER MARKS: ");
		for(j=0;j<5;j++)
		{
			printf("\nSubject %d: ",j+1);
			scanf("%d",&list[i].marks[j]);
		}
		
	}
}
void calc(struct student list[100],int s)
{
	int i,j,tm;
	for(i=0;i<s;i++)
	{
		tm=0;
		for(j=0;j<5;j++)
			tm=tm+list[i].marks[j];
	list[i].TM=tm;
	list[i].per=(tm/500.0)*100.0;
	}
	
}

void display_a(struct student list[100],int s)
{
	int i;
	printf("%-10s\t%-15s\tSUBJECT 1\tSUBJECT 2\tSUBJECT 3\tSUBJECT 4\tSUBJECT 5\t%-16s\t%-10s\n\n","NAME","ROLL","TOTAL MARKS","PERCENTAGE");
	for(i=0;i<s;i++)
		printf("%-10s\t%-15d\t%-9d\t%-9d\t%-9d\t%-9d\t%-9d\t%-16d\t%-8.2f%c\n",list[i].name,list[i].roll,list[i].marks[0],list[i].marks[1],list[i].marks[2],list[i].marks[3],list[i].marks[4],list[i].TM,list[i].per,37);
}

void rollsearch_b(struct student list[100],int s)
	{
		int Roll,i;
		printf("\n\nENTER roll no(to be searched): ");
		scanf("%d",&Roll);
		
		for(i=0;i<s;i++)
			if(Roll==list[i].roll)
					printf("%-10s\t%-15d\t%-9d\t%-9d\t%-9d\t%-9d\t%-9d\t%-16d\t%-8.2f%c\n",list[i].name,list[i].roll,list[i].marks[0],list[i].marks[1],list[i].marks[2],list[i].marks[3],list[i].marks[4],list[i].TM,list[i].per,37);
	printf("\n\n");
	}
	
void percent_range_c(struct student list[100],int s)
	{
		float l,up;
		int i;
		printf("ENTER THE RANGE : LOWER limit : ");
		scanf("%f",&l);
		printf("Enter THE UPPER LIMIT: ");
		scanf("%f",&up);
		printf("STUDENT who scored between %0.2f - %0.2f are :\n\n",l,up);
		for(i=0;i<s;i++)
			if(list[i].per>=l&&list[i].per<=up)
				printf("%-10s\t%-15d\t%-9d\t%-9d\t%-9d\t%-9d\t%-9d\t%-16d\t%-8.2f%c\n\n",list[i].name,list[i].roll,list[i].marks[0],list[i].marks[1],list[i].marks[2],list[i].marks[3],list[i].marks[4],list[i].TM,list[i].per,37);
	printf("\n\n");
	}
	
	void sort_d(struct student list[100],int s)
	{
		int i,j;
		struct student temp;
		for(i=1;i<s;i++)
		{
			for(j=0;j<s-i;j++)
				{
					if(list[j].TM<list[j+1].TM)
					{
						temp=list[j];
						list[j]=list[j+1];
						list[j+1]=temp;
					}
				}
		}
	}
	
int main()
{
	int i,n;
	printf("Enter the number of Student: ");
	scanf("%d",&n);
	struct student var[n];
	
	accept(var,n);
	calc(var,n);
	display_a(var,n);
	rollsearch_b(var,n);
	percent_range_c(var,n);
	sort_d(var,n);
	printf("\n\nSORTED LIST(acording to marks):\n\n");
	display_a(var,n);
	
	printf("\n---------------program over------------------------");
	return 0;
}
