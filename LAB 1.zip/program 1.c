/*
Jayash prem
OOP LAB 1 question 1
*/
struct student{
	char name[20];
	long int roll;
	int marks[5];
};

#include<stdio.h>
int main()
{
	int i;
	struct student var;
	printf("enter the name of student: ");
	scanf(" %[^\n]s",&var.name);
	printf("enter the roll number of the student: ");
	scanf("%d",&var.roll);
	printf("Enter the marks :\n");
	for(i=0;i<5;i++)
		{
			printf("\nSubject %d: ",i+1);
			scanf("%d",&var.marks[i]);
			}
	printf("\n\n");
	printf("Name: %s",var.name);
	printf("\nRoll: %d",var.roll);
	printf("\nMarks:\n");
	for(i=0;i<5;i++)
		{
			printf("Subject %d : %d\n",i+1,var.marks[i]);
		}
	printf("\n------------------\n");
	return 0;
}
