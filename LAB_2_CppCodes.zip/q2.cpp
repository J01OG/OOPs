/*
Q2 WAP to find centigrade for a given Fahrenheit temperature.
*/
#include<iostream>
using namespace std;

int main()
{
	float f;
	cout<<"ENTER FARENHEIGHT: ";	
	cin>>f; 
	cout<<(f-32.0)*5.0/9.0<< " FAHRENHEIT";

	return 0;
}
