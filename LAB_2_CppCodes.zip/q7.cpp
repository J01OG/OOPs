//Q7. WAP to read an alphabet from the user and convert it into uppercase if the entered alphabet is in 
//lowercase, otherwise display an appropriate message.

#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<"ENTER THE alphabet: ";
	cin>>ch;
	if(ch>=97&&ch<=122)
		cout<<"UPPERCASE: "<<((char)(ch-32));
	else
		cout<<"error!not an lower case charcter";
	return 0;
}
