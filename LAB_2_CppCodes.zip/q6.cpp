//Q6. WAP to find the largest between two numbers.
#include<iostream>
using namespace std;
int main()
{
	int a,b,max;
	cout<<"ENTER A THEN B : ";
	cin>>a>>b;
	max=a>b?a:b;
	cout<<"LARGER NUMBER: "<<max;
	return 0;
}
