//Q1.WAP to perform the addition 
//of two integers and display the result.
#include<iostream>
using namespace std;

int main()
{
	int a,b;
	cin>>a>>b;
	cout<<a+b;
	
	return 0;
}
