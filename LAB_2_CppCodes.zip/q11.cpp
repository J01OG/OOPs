//Q11. WAP to calculate the factorial of a given number
#include<iostream>
using namespace std;
int main()
{
	int n,f=1,i;
	cout<<"ENTER THE NUMBER: ";
	cin>>n;
	for(i=1;i<=n;i++)
	f=f*i;
	
	cout<<"FACTORIAL: "<<f;
	return 0;
}
