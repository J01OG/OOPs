//Q9. WAP to print the natural numbers from 1 to 20.
#include<iostream>
using namespace std;
int main()
{
	int i;
	cout<<"NATURAL NUMBER BETWEEN 1 TO 20: ";
	for(i=1;i<=20;i++)
	cout<<i<<" ";
	return 0;
}
