//Q4. WAP to calculate area of a triangle whose base and height is given.

#include<iostream>
using namespace std;
int main()
{
	float h,b;
	cout<<"ENTER BASE: ";
	cin>>b;
	cout<<"ENTER HEIGHT: ";
	cin>>h;
	cout<<"AREA: "<<(1.0/2.0)*b*h;
	
	return 0;
}
