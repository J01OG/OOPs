//Q10. WAP to print all numbers within a given range. The range is given by user.
#include<iostream>
using namespace std;
int main()
{
	int a,b,i;
	cout<<"ENTER RANGE: ";
	cin>>a>>b;
	for(i=a;i<=b;i++)
	cout<<i<<" ";
	return 0;
}
