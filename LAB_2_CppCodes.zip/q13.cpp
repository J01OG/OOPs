//Q13. WAP to check whether a number n is prime number or not.
#include<iostream>
using namespace std;
int main()
{
	int n,i,c=0;
	cout<<"ENTER THE NUMBER: ";
	cin>>n;
	for(i=1;i<=n;i++)
		if(n%i==0)
			c++;
			
	if(c==2)
		cout<<n<<" is a prime number";
	else
		cout<<n<<" is not a prime number";
	return 0;
}
