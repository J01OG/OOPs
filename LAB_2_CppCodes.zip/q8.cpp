//Q8. WAP to input any two integers, and provide a menu to the user to select any of the options as add,
//subtract, multiply, divide and display the result accordingly.


#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	float d;
	cout<<"ENTER VALUE OF A THE B: ";
	cin>>a>>b;
	do
	{
		cout<<"\n--------------MENU-----------------\n1.ADD\n2.SUBSTRACT\n3.MULTPLY\n4.DIVIDE\n5.EXIT\nENTER CHOICE (1/2/3/4/5): ";
		cin>>c;
		switch (c)
		{
			case 1:cout<<"\nADDITION: "<<a+b;break;
			case 2:cout<<"\nSUBSTRACTION: "<<a-b;break;
			case 3:cout<<"\nMULTIPLICATION: "<<a*b;break;
			case 4:d=float(a)/float(b);cout<<"\nDIVISION: "<<d;break;
			case 5:break;
			default :cout<<"\nINVALIDE INPUT PLS GO AGAIN\n ";break;
		}
	}while(c!=5);
		
	
	return 0;
}
