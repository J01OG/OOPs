//Q5 WAP to swap two integer numbers using third variable.

#include<iostream>
using namespace std;
int main()
{
	int a,b,temp;
	cout<<"ENTER A THEN B: ";
	cin>>a>>b;
	cout<<"BEFORE SWAP A: "<<a<<" B: "<<b<<"\n";
	temp=a;
	a=b;
	b=temp;
	cout<<"AFTER SWAP A: "<<a<<" B: "<<b;
	return 0;
}
