//Q3. WAP to calculate area of a circle.

#include<iostream>
using namespace std;
int main()
{
	float a,r;
	cout<<"ENTER RADIUS: ";
	cin>>r;
	cout<<"AREA: "<<(22/7)*r*r;
	
	return 0;
}
