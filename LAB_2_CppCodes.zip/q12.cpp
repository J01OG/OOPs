//Q12. WAP to calculate the sum of digits of a given number

#include<iostream>
using namespace std;
int main()
{
	int n,i,sum,rem;
	cout<<"ENTER THE NUMBER: ";
	cin>>n;
	while(n!=0)
	{
		sum+=n%10;
		n=n/10;
	}
	cout<<"sum: "<<sum;
	return 0;
}
